//Variable
const Ids = { //Element Ids
 Iframe : document.getElementById("If"), //Main Iframe
};
//Main Menu
function CustomSite(){ //Set custom site btn
 Ids.Iframe.src = document.getElementById("CustomSiteURLForm").value;
}
function ReloadIf(){ //Reload Iframe
    Ids.Iframe.src = Ids.Iframe.src;
}

//Set Iframe site
function TapiHomePage(){
 Ids.Iframe.src = "https://tapioka-site.f5.si/";
}
function SakaiHomePage(){
 Ids.Iframe.src = "https://sakai-site.f5.si/";
}
function YouTube(){ //YouTube
 Ids.Iframe.src = "https://tubo.reallyaweso.me/";
}
function TikTok(){ //TikTok
 Ids.Iframe.src = "https://urlebird.com/jp/videos/";
}
function Pixiv(){ //Pixiv
 Ids.Iframe.src = "https://lxv.dc09.ru/";
}

//Other function
 function UseAnother(){ //Use another site
 if(Ids.Iframe.src === "https://tubo.reallyaweso.me/"){
    Ids.Iframe.src = "https://piped.private.coffee/trending";
     alert(`Change to ${Ids.Iframe.src}\n${Ids.Iframe.src} �ɕύX���܂����B`);
 }else if(Ids.Iframe.src ==="https://piped.private.coffee/trending"){
    Ids.Iframe.src = "https://piped.wireway.ch/trending";
     alert(`Change to ${Ids.Iframe.src}\n${Ids.Iframe.src} �ɕύX���܂����B`);
 }else if(Ids.Iframe.src === "https://piped.wireway.ch/trending"){
    Ids.Iframe.src = "https://tubo.reallyaweso.me/";
     alert(`Change to ${Ids.Iframe.src}\n${Ids.Iframe.src} �ɕύX���܂����B`);
 }else{
    ;
 }
}//end