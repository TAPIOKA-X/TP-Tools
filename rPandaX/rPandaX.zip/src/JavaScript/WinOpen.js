function Open_TS_EDITOR(){ //TS Editor
 window.open("src/window_open/TsEditor.html",null,"width=700,height=600");
}

function Open_Creators(){
 window.open("src/window_open/CREATORS.html",null,"width=700,height=600");
}