var Iframe=document.getElementById("Iframe");
//URL
var TPH="https://tapioka-site.f5.si/";
var PVURL="https://litexiv.bloat.cat/";
var TKLink="https://urlebird.com/";
var DRLink="https://bad-time-simulator.com/deltarune";
var MCLink="https://eaglercraft.com/mc/1.8.8/";
function TP_HomePage(){
 Iframe.src=TPH;
}
function Pixiv(){
 Iframe.src=PVURL;
}
function TikTok(){
 Iframe.src=TKLink;
}
function Deltarune(){
 Iframe.src=DRLink;
}
function Minecraft(){
 Iframe.src=MCLink;
}